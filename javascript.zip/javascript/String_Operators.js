let s1 = "Dipen";
let s2 = "vaghasiya";
let s3 = s1 + " " + s2;
document.write(s3);